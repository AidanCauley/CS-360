package com.example.ac_mod3_cs_360;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private DatabaseHelper databaseHelper;
    private boolean smsAllowed = false;

    private EditText editItemName;
    private EditText editItemQuantity;
    private LinearLayout databaseListContainer;

    private String selectedItemName = "";
    private String lastSmsAlertMessage = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new DatabaseHelper(this);

        // Start the app on the login screen.
        showLoginScreen();
    }

    private void showLoginScreen() {
        setContentView(R.layout.activity_login);

        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.createUser(username, password);

            if (created) {
                Toast.makeText(this, "Account created.", Toast.LENGTH_SHORT).show();
                showSmsPermissionScreen();
            } else {
                Toast.makeText(this, "Account already exists or could not be created.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean validLogin = databaseHelper.checkLogin(username, password);

            if (validLogin) {
                Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
                showSmsPermissionScreen();
            } else {
                Toast.makeText(this, "Invalid login. Create an account first.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSmsPermissionScreen() {
        setContentView(R.layout.activity_sms_permission);

        Button buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonDeclineSms = findViewById(R.id.buttonDeclineSms);

        buttonAllowSms.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 100);
            } else {
                smsAllowed = true;
                Toast.makeText(this, "SMS alerts allowed.", Toast.LENGTH_SHORT).show();
                showInventoryScreen();
            }
        });

        buttonDeclineSms.setOnClickListener(v -> {
            smsAllowed = false;
            Toast.makeText(this, "SMS alerts declined. App will still work.", Toast.LENGTH_SHORT).show();
            showInventoryScreen();
        });
    }

    private void showInventoryScreen() {
        setContentView(R.layout.activity_inventory);

        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonIncreaseQuantity = findViewById(R.id.buttonIncreaseQuantity);
        Button buttonDecreaseQuantity = findViewById(R.id.buttonDecreaseQuantity);
        Button buttonRemoveItem = findViewById(R.id.buttonRemoveItem);

        TextView lowStockAlert = findViewById(R.id.lowStockAlert);

        addCurrentInventoryTableToScreen();

        // Allows the user to type an exact quantity and press Done/checkmark.
        editItemQuantity.setOnEditorActionListener((v, actionId, event) -> {
            boolean donePressed = actionId == EditorInfo.IME_ACTION_DONE;
            boolean enterPressed = event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            boolean softKeyboardCheckPressed = actionId == EditorInfo.IME_NULL;

            if (donePressed || enterPressed || softKeyboardCheckPressed) {
                setTypedQuantity(lowStockAlert);
                editItemQuantity.clearFocus();
                return true;
            }

            return false;
        });

        buttonAddItem.setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;

            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean added = databaseHelper.addItem(itemName, quantity);

            if (added) {
                Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();
                selectedItemName = itemName;
                editItemName.setText("");
                editItemQuantity.setText("");
                refreshInventoryDisplay(lowStockAlert);
            } else {
                Toast.makeText(this, "Item already exists or could not be added.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonIncreaseQuantity.setOnClickListener(v -> {
            String itemName = getSelectedOrTypedItemName();

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Tap an item or type an item name first.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = databaseHelper.increaseQuantity(itemName);

            if (updated) {
                Toast.makeText(this, "Quantity increased.", Toast.LENGTH_SHORT).show();
                refreshInventoryDisplay(lowStockAlert);
            } else {
                Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonDecreaseQuantity.setOnClickListener(v -> {
            String itemName = getSelectedOrTypedItemName();

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Tap an item or type an item name first.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = databaseHelper.decreaseQuantity(itemName);

            if (updated) {
                Toast.makeText(this, "Quantity decreased.", Toast.LENGTH_SHORT).show();
                refreshInventoryDisplay(lowStockAlert);
            } else {
                Toast.makeText(this, "Item not found or quantity is already zero.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonRemoveItem.setOnClickListener(v -> {
            String itemName = getSelectedOrTypedItemName();

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Tap an item or type an item name first.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean deleted = databaseHelper.deleteItem(itemName);

            if (deleted) {
                Toast.makeText(this, "Item removed.", Toast.LENGTH_SHORT).show();
                selectedItemName = "";
                editItemName.setText("");
                editItemQuantity.setText("");
                refreshInventoryDisplay(lowStockAlert);
            } else {
                Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            }
        });

        refreshInventoryDisplay(lowStockAlert);
    }

    private void setTypedQuantity(TextView lowStockAlert) {
        String itemName = getSelectedOrTypedItemName();
        String quantityText = editItemQuantity.getText().toString().trim();

        if (itemName.isEmpty()) {
            Toast.makeText(this, "Tap an item or type an item name first.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (quantityText.isEmpty()) {
            Toast.makeText(this, "Enter the new quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int newQuantity;

        try {
            newQuantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateItemQuantity(itemName, newQuantity);

        if (updated) {
            Toast.makeText(this, "Quantity updated.", Toast.LENGTH_SHORT).show();
            refreshInventoryDisplay(lowStockAlert);
        } else {
            Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
        }
    }

    private String getSelectedOrTypedItemName() {
        String typedName = editItemName.getText().toString().trim();

        if (!typedName.isEmpty()) {
            return typedName;
        }

        return selectedItemName;
    }

    private void addCurrentInventoryTableToScreen() {
        ViewGroup content = findViewById(android.R.id.content);

        if (content == null || content.getChildCount() == 0) {
            return;
        }

        if (content.getChildAt(0) instanceof ScrollView) {
            ScrollView scrollView = (ScrollView) content.getChildAt(0);

            if (scrollView.getChildAt(0) instanceof LinearLayout) {
                LinearLayout layout = (LinearLayout) scrollView.getChildAt(0);

                TextView header = new TextView(this);
                header.setText("Current Inventory");
                header.setTextSize(18);
                header.setTextColor(Color.rgb(31, 41, 55));
                header.setTypeface(null, Typeface.BOLD);
                header.setPadding(0, 24, 0, 10);

                TextView instructions = new TextView(this);
                instructions.setText("Tap an item row to select it. Then use + Quantity, - Quantity, Remove Selected Item, or type a new quantity and press Done/checkmark.");
                instructions.setTextSize(13);
                instructions.setTextColor(Color.rgb(107, 114, 128));
                instructions.setPadding(0, 0, 0, 10);

                databaseListContainer = new LinearLayout(this);
                databaseListContainer.setOrientation(LinearLayout.VERTICAL);
                databaseListContainer.setBackgroundColor(Color.WHITE);
                databaseListContainer.setPadding(12, 12, 12, 12);

                layout.addView(header);
                layout.addView(instructions);
                layout.addView(databaseListContainer);
            }
        }
    }

    private void refreshInventoryDisplay(TextView lowStockAlert) {
        if (databaseListContainer == null) {
            return;
        }

        databaseListContainer.removeAllViews();

        addTableHeader();

        Cursor cursor = databaseHelper.getAllItems();

        boolean lowStockFound = false;
        String lowStockItem = "";

        if (cursor.getCount() == 0) {
            TextView emptyMessage = new TextView(this);
            emptyMessage.setText("No inventory items have been added yet.");
            emptyMessage.setTextSize(14);
            emptyMessage.setTextColor(Color.rgb(107, 114, 128));
            emptyMessage.setPadding(0, 12, 0, 12);
            databaseListContainer.addView(emptyMessage);

            lowStockAlert.setText("No low-stock alerts yet.");
        } else {
            while (cursor.moveToNext()) {
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_QUANTITY));

                String status;

                if (quantity == 0) {
                    status = "Out";
                    lowStockFound = true;
                    lowStockItem = itemName;
                } else if (quantity <= 3) {
                    status = "Low";
                    lowStockFound = true;
                    lowStockItem = itemName;
                } else {
                    status = "In Stock";
                }

                final String currentItemName = itemName;
                final int currentQuantity = quantity;

                LinearLayout row = createInventoryTableRow(itemName, String.valueOf(quantity), status, false);

                row.setOnClickListener(v -> {
                    selectedItemName = currentItemName;
                    editItemName.setText(currentItemName);
                    editItemQuantity.setText(String.valueOf(currentQuantity));
                    Toast.makeText(this, currentItemName + " selected.", Toast.LENGTH_SHORT).show();
                });

                databaseListContainer.addView(row);
            }

            if (lowStockFound) {
                String alertMessage = "Alert: " + lowStockItem + " is low or out of stock.";
                lowStockAlert.setText(alertMessage);
                sendLowStockSms(alertMessage);
            } else {
                lowStockAlert.setText("All inventory items are currently in stock.");
            }
        }

        cursor.close();
    }

    private void addTableHeader() {
        LinearLayout headerRow = createInventoryTableRow("Item", "Qty", "Status", true);
        databaseListContainer.addView(headerRow);
    }

    private LinearLayout createInventoryTableRow(String itemText, String quantityText, String statusText, boolean isHeader) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 8, 0, 8);

        TextView itemView = createTableText(itemText, 3, isHeader, Color.rgb(31, 41, 55));
        TextView quantityView = createTableText(quantityText, 1, isHeader, Color.rgb(31, 41, 55));

        int statusColor = Color.rgb(31, 41, 55);

        if (statusText.equals("Low")) {
            statusColor = Color.rgb(180, 83, 9);
        } else if (statusText.equals("Out")) {
            statusColor = Color.rgb(220, 38, 38);
        } else if (statusText.equals("In Stock")) {
            statusColor = Color.rgb(5, 150, 105);
        }

        TextView statusView = createTableText(statusText, 1, isHeader, statusColor);

        row.addView(itemView);
        row.addView(quantityView);
        row.addView(statusView);

        return row;
    }

    private TextView createTableText(String text, int weight, boolean isHeader, int textColor) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(isHeader ? 14 : 13);
        textView.setTextColor(textColor);
        textView.setPadding(4, 4, 4, 4);

        if (isHeader) {
            textView.setTypeface(null, Typeface.BOLD);
        }

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                weight
        );

        textView.setLayoutParams(params);

        return textView;
    }

    private void sendLowStockSms(String message) {
        if (!smsAllowed) {
            return;
        }

        if (message.equals(lastSmsAlertMessage)) {
            return;
        }

        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();

                // Emulator test number for class testing.
                smsManager.sendTextMessage("5554", null, message, null, null);

                lastSmsAlertMessage = message;
                Toast.makeText(this, "SMS low-stock alert sent.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS alert could not be sent, but the app still works.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsAllowed = true;
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                smsAllowed = false;
                Toast.makeText(this, "SMS permission denied. App will still work.", Toast.LENGTH_SHORT).show();
            }

            showInventoryScreen();
        }
    }
}