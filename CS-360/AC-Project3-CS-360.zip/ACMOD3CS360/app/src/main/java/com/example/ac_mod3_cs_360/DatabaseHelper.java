package com.example.ac_mod3_cs_360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String TABLE_INVENTORY = "inventory";
    public static final String ITEM_ID = "id";
    public static final String ITEM_NAME = "item_name";
    public static final String ITEM_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE, " +
                PASSWORD + " TEXT)";

        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ITEM_NAME + " TEXT UNIQUE, " +
                ITEM_QUANTITY + " INTEGER)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Creates a new user account.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Checks whether the username and password match an account in the database.
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + USERNAME + " = ? AND " + PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean loginExists = cursor.getCount() > 0;
        cursor.close();

        return loginExists;
    }

    // Adds a new inventory item.
    public boolean addItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    // Gets all inventory items.
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY + " ORDER BY " + ITEM_NAME + " ASC",
                null
        );
    }

    // Updates an item's quantity.
    public boolean updateItemQuantity(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_QUANTITY, quantity);

        int result = db.update(
                TABLE_INVENTORY,
                values,
                ITEM_NAME + " = ?",
                new String[]{itemName}
        );

        return result > 0;
    }

    // Increases an item's quantity by 1.
    public boolean increaseQuantity(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + ITEM_QUANTITY + " FROM " + TABLE_INVENTORY + " WHERE " + ITEM_NAME + " = ?",
                new String[]{itemName}
        );

        if (cursor.moveToFirst()) {
            int currentQuantity = cursor.getInt(0);
            cursor.close();
            return updateItemQuantity(itemName, currentQuantity + 1);
        }

        cursor.close();
        return false;
    }

    // Decreases an item's quantity by 1.
    public boolean decreaseQuantity(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + ITEM_QUANTITY + " FROM " + TABLE_INVENTORY + " WHERE " + ITEM_NAME + " = ?",
                new String[]{itemName}
        );

        if (cursor.moveToFirst()) {
            int currentQuantity = cursor.getInt(0);
            cursor.close();

            if (currentQuantity > 0) {
                return updateItemQuantity(itemName, currentQuantity - 1);
            }
        } else {
            cursor.close();
        }

        return false;
    }

    // Deletes an item from the inventory.
    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_INVENTORY,
                ITEM_NAME + " = ?",
                new String[]{itemName}
        );

        return result > 0;
    }
}